#include<stdio.h>   // Header file for the printf and scanf

// Prototype of the function
int Maximum(int, int);
