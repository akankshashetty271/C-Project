

/////////////////////////////////////////////////////////////
//
//  Function name:  Maximum
//  Input :              Integer, Integer
//  Output :            Integer
//  Description :      It is used to find out the largest number
//  Date :               23/02/2021
//  Author :            Piyush Manohar Khairnar
//
/////////////////////////////////////////////////////////////

int Maximum(int iValue1, int iValue2)
{
    if(iValue1 > iValue2)
    {
        return iValue1;
    }
    else
    {
        return iValue2;
    }
}



