#include<stdio.h>
void Reverse(int Arr[])
{
    char *start, *end;
    char temp;
    if(Arr == NULL)
    {
        return;
    }
    start = Arr;
    end = Arr;
    while(*end != '\0')
    {
        end++;
    }
    end--;
    while(start < end)
    {
        temp = *start;
        *start = *end;
        *end = * temp;
    }

}
int main()
{
    char arr[10];
    printf("Enyer the string:");
    scanf("%[^'\n']s", Arr);
    Reverse(Arr);
    printf("Reverse string : %s\n", Arr);
    return 0;
}
